
NOTE:  This demo is not described in the text.  We include it 
to illustrate some of the techniques that we couldn't present
in the text because of lack of space.

We hope you'll find the techniques presented in this demo 
interesting and useful.

Enjoy!